海南大学官网 [https://ha.hainanu.edu.cn/home2020/](https://ha.hainanu.edu.cn/home2020/)

海南大学网上服务大厅 [https://ehall.hainanu.edu.cn/](https://ehall.hainanu.edu.cn/)

海南大学网络教学综合平台 [https://jxpt.hainanu.edu.cn/meol/](https://jxpt.hainanu.edu.cn/meol/)

---

智慧树 [https://www.zhihuishu.com/](https://www.zhihuishu.com/)

超星学习通 [http://hainu.fy.chaoxing.com/](http://hainu.fy.chaoxing.com/)

中国大学MOOC [https://www.icourse163.org/](https://www.icourse163.org/)